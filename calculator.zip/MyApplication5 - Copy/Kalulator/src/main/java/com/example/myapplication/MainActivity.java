package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private boolean isOpPressed = false;

    private double firstNumber = 0;

    private int secondNumberIndex = 0;

    private char currentOp = 0;

    private boolean isDot = false;

    private TextView calculatorScreen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        calculatorScreen =findViewById(R.id.calculatorScreen);
        final Button
                 n0 = findViewById(R.id.n0)
                ,n1 = findViewById(R.id.n1)
                ,n2 = findViewById(R.id.n2)
                ,n3 = findViewById(R.id.n3)
                ,n4 = findViewById(R.id.n4)
                ,n5 = findViewById(R.id.n5)
                ,n6 = findViewById(R.id.n6)
                ,n7 = findViewById(R.id.n7)
                ,n8 = findViewById(R.id.n8)
                ,n9 = findViewById(R.id.n9)
                ,dot = findViewById(R.id.dot)
                ,equall = findViewById(R.id.equall)
                ,subtraction = findViewById(R.id.subtraction)
                ,add = findViewById(R.id.add)
                ,multiplication = findViewById(R.id.multiplication)
                ,division= findViewById(R.id.division);

        final View.OnClickListener calculatorLisner= new View.OnClickListener() {
            @Override
            public  void onClick(View v) {
                final int id = v.getId();
                switch (id){
                    case R.id.n0:
                        calculatorScreen.append("0");
                        break;
                    case R.id.n1:
                        calculatorScreen.append("1");
                        break;
                    case R.id.n2:
                        calculatorScreen.append("2");
                        break;
                    case R.id.n3:
                        calculatorScreen.append("3");
                        break;
                    case R.id.n4:
                        calculatorScreen.append("4");
                        break;
                    case R.id.n5:
                        calculatorScreen.append("5");
                        break;
                    case R.id.n6:
                        calculatorScreen.append("6");
                        break;
                    case R.id.n7:
                        calculatorScreen.append("7");
                        break;
                    case R.id.n8:
                        calculatorScreen.append("8");
                        break;
                    case R.id.n9:
                        calculatorScreen.append("9");
                        break;
                    case R.id.dot:
                        if(!isDot){
                            String screenContent = calculatorScreen.getText().toString();
                            final int screenContentLength = screenContent.length();
                            if(screenContentLength<1){
                                return;
                            }
                            char lastChar = screenContent.charAt(screenContentLength-1);
                            if(lastChar == '/'||lastChar == '+'||lastChar == '-'||lastChar == '*') {
                                return;
                            }
                            calculatorScreen.append(".");
                            isDot = true;
                        }
                        break;
                    case R.id.equall:
                        if(isOpPressed) {
                            String screenContent = calculatorScreen.getText().toString();
                            char lastChar = screenContent.charAt(screenContent.length()-1);
                            if(lastChar == '/'||lastChar == '+'||lastChar == '-'||lastChar == '*') {
                                return;
                            }
                            String secondNumberString = screenContent.substring(secondNumberIndex,screenContent.length());
                            double secondNumber = Double.parseDouble(secondNumberString);
                            String result;
                            if(currentOp == '+') {
                                secondNumber += firstNumber;
                            } else if(currentOp == '-') {
                                secondNumber = firstNumber - secondNumber;
                            } else if(currentOp =='*'){
                                secondNumber *= firstNumber;
                            } else if(currentOp =='/' ){
                                if(secondNumber == 0){
                                    return;
                                }
                                secondNumber= firstNumber / secondNumber;
                            }


                            result = String.valueOf(secondNumber);
                            if(result.endsWith(".0")){ result = result.substring(0,result.length()-2);}
                            calculatorScreen.setText(result);
                            isOpPressed = false;
                            }
                        break;
                    case R.id.add:
                        opPressed('+');

                        break;
                    case R.id.subtraction:
                        opPressed( '-');
                        break;
                    case R.id.multiplication:
                        opPressed( '*');

                        break;
                    case R.id.division:
                        opPressed( '/');

                        break;
                }
            }
        };
        n0.setOnClickListener(calculatorLisner);
        n1.setOnClickListener(calculatorLisner);
        n2.setOnClickListener(calculatorLisner);
        n3.setOnClickListener(calculatorLisner);
        n4.setOnClickListener(calculatorLisner);
        n5.setOnClickListener(calculatorLisner);
        n6.setOnClickListener(calculatorLisner);
        n7.setOnClickListener(calculatorLisner);
        n8.setOnClickListener(calculatorLisner);
        n9.setOnClickListener(calculatorLisner);

        equall.setOnClickListener(calculatorLisner);
        dot.setOnClickListener(calculatorLisner);

        add.setOnClickListener(calculatorLisner);
        subtraction.setOnClickListener(calculatorLisner);
        multiplication.setOnClickListener(calculatorLisner);
        division.setOnClickListener(calculatorLisner);

        final Button delete= findViewById(R.id.del);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String displayedElements = calculatorScreen.getText().toString();
                int lenght = displayedElements.length();
                if (lenght > 0) {
                    displayedElements = displayedElements.substring(0,lenght-1);
                    calculatorScreen.setText(displayedElements);
                }
            }
        });

        final Button clearEverything = findViewById(R.id.ce);
        clearEverything.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatorScreen.setText("");
                isDot = false;
                isOpPressed= false;
            }
        });

    }
    private void opPressed(char operation){
        if(isOpPressed){
            return;
        }
        String screenContent = calculatorScreen.getText().toString();
        final int screenContentLengh = screenContent.length();
        if(screenContentLengh < 1) {
            return;
        }
        secondNumberIndex = screenContentLengh + 1;
        firstNumber = Double.parseDouble(screenContent);
        calculatorScreen.append(String.valueOf(operation));

        isOpPressed = true;
        isDot = false;

        currentOp = operation;
    }
}
